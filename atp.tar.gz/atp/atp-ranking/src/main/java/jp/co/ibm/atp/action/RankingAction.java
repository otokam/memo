package jp.co.ibm.atp.action;

public class RankingAction {
	public String index() {
		System.out.println("hello world");
		return "success";
	}
}
