package jp.co.ibm.atp.action;

public class SampleAction {
	public String hello() {
		System.out.println("hello");
		return "success";
	}
}
