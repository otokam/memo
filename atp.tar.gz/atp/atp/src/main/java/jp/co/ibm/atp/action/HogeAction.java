package jp.co.ibm.atp.action;

public class HogeAction {
	public String index() {
		System.out.println("hogeeeeee");
		return "success";
	}
}
